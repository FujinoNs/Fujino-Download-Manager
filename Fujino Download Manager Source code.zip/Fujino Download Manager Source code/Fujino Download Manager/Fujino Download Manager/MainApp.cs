﻿using AltoHttp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Fujino_Download_Manager
{
    public partial class MainApp : Form
    {
        public MainApp()
        {
            InitializeComponent();
        }

        private void btn_Resume_Click(object sender, EventArgs e)
        {
            httpDownloader.Resume();
        }

        private void btn_Pause_Click(object sender, EventArgs e)
        {
            httpDownloader.Pause();
        }

        private HttpDownloader httpDownloader = null;
        private void btn_Start_Click(object sender, EventArgs e)
        {
            httpDownloader = new HttpDownloader(txt_Url.Text, $"{Application.StartupPath}\\{Path.GetFileName(txt_Url.Text)}");
            httpDownloader.DownloadCompleted += HttpDownloader_DownloadCompleted;
            httpDownloader.ProgressChanged += HttpDownloader_ProgressChanged;
            httpDownloader.Start();
        }

        private void HttpDownloader_ProgressChanged(object sender, AltoHttp.ProgressChangedEventArgs e)
        {
            pgb_status.Value = (int)e.Progress;
            lbl_Percent.Text = $"{e.Progress.ToString("0.00")} % ";
            lbl_Speed.Text = string.Format("{0} MB/s", (e.SpeedInBytes / 1024d / 1024d).ToString("0.00"));
            lbl_Size.Text = string.Format("{0} MB", (httpDownloader.TotalBytesReceived / 1024d / 1024d).ToString("0.00"));
            lbl_Status.Text = "Downloading...";
        }

        private void HttpDownloader_DownloadCompleted(object sender, EventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                lbl_Status.Text = "Finished";
                lbl_Percent.Text = "100%";
            });
        }

        private void btn_mygithub_Click(object sender, EventArgs e)
        {
            Process.Start("https://fujinons.github.io/");
        }
    }
}
